#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"
#include "ui/CocosGUI.h"


using namespace cocos2d;
#include "cocos2d.h"
using namespace cocos2d::ui; // Incluye el espacio de nombres para los widgets de UI
USING_NS_CC;






class FirstLevelScene : public Scene {
private:
    
    
    
    Sprite* character = nullptr;
    Sprite* enemy = nullptr;

    cocos2d::Sprite* background1;
    cocos2d::Sprite* background2;
    SpriteFrame* idleFrame; // Frame inicial (parado)
    Vector<SpriteFrame*> walkRightFrames;
    Vector<SpriteFrame*> walkLeftFrames;
    Vector<SpriteFrame*> jumpUpFrames;  // Frames para la animación de salto
    Vector<SpriteFrame*> jumpDownFrames;  // Frames para la animación de salto
    Vector<SpriteFrame*> duckFrames;  // vector para almacenar los frames de agacharse
    Vector<SpriteFrame*> shootFrames; // Frames de la animación de disparo

    

    bool isJumping = false;          // Para evitar múltiples saltos
    bool isDucking = false;  // Variable para verificar si el personaje está agachado
    bool isMoving;
    bool isHolding;
    bool isShooting = false;  // Variable para controlar si el personaje está disparando
    bool isHoldingShoot = false;  // Variable para detectar si el botón está siendo presionado


    EventListenerTouchOneByOne* touchListener;
    Sprite* background;
    float backgroundMinX;
    float backgroundMaxX;

public:
    static Scene* createScene() {
        return FirstLevelScene::create();
        void loadJumpFrames();
            void loadDuckFrames();
            void moveCharacter(bool toRight, bool isShortTouch);
            void jumpCharacter();
            void duckCharacter();
            void shootCharacter();
            void stopShooting();
            void spawnEnemy(Scene* scene);
            void shootBullet(Sprite* character, Sprite* enemy, Scene* scene);

        
        bool onTouchBegan(Touch* touch, Event* event);
        void onTouchEnded(Touch* touch, Event* event);
            
    }

    virtual bool init() {
        if (!Scene::init()) {
            return false;
        }

        auto visibleSize = Director::getInstance()->getVisibleSize();
        auto origin = Director::getInstance()->getVisibleOrigin();

   
        // Crear el fondo
                auto background = Sprite::create("level1.png");
                if (!background) {
                    CCLOG("Error: No se pudo cargar la imagen del fondo level1.png");
                    return false;
                }

                background->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
                background->setAnchorPoint(Vec2(0.5f, 0.5f));
                background->setScale(std::max(visibleSize.width / background->getContentSize().width,
                                              visibleSize.height / background->getContentSize().height));
                this->addChild(background, 0); // Fondo detrás de todos los elementos

        // Crear el sprite del personaje
        character = Sprite::create("personaje.png");
        if (!character) {
            CCLOG("Error: No se pudo cargar la imagen del personaje personaje.png");
            return false;
        }

        // Hacer que el personaje sea más grande
        character->setScale(1.7f); // Ajusta el valor aquí para hacer el personaje más grande

        // Posicionar el personaje en la esquina inferior izquierda, un poco más abajo
        character->setPosition(Vec2(origin.x + character->getContentSize().width / 2,
                                     origin.y + character->getContentSize().height / 2 - 15)); // Baja 50 unidades


        character->setAnchorPoint(Vec2(0.5f, 0.5f));
        character->setName("character");  // Asignar nombre al personaje

        this->addChild(character, 1);

        loadFrames();
        loadJumpFrames();  // Cargar los frames del salto
        createDirectionalButtons();
        loadShootFrames();  // Cargar los frames de disparo
        spawnEnemy(this);  // Pasamos la escena actual para agregar al enemigo
        if (enemy) {
            CCLOG("El enemigo se creó correctamente.");
        } else {
            CCLOG("Error: El enemigo sigue siendo nulo.");
        }



        // Configurar el frame parado (usar el primer frame de la animación a la derecha)
        if (!walkRightFrames.empty()) {
            idleFrame = walkRightFrames.at(0);
        } else {
            idleFrame = nullptr; // Evitar errores si no se cargan frames
        }

        // Inicializar el manejo de toques en pantalla
        touchListener = EventListenerTouchOneByOne::create();
        touchListener->onTouchBegan = CC_CALLBACK_2(FirstLevelScene::onTouchBegan, this);
        touchListener->onTouchEnded = CC_CALLBACK_2(FirstLevelScene::onTouchEnded, this);
        _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

        isMoving = false;
        isHolding = false;
        return true;
    }
    
    void checkEnemyInitialization() {
        CCLOG("Comprobando inicialización de enemigo...");
        if (!enemy) {
            CCLOG("ERROR: enemy sigue siendo nulo.");
        } else {
            CCLOG("enemy está inicializado correctamente.");
        }
    }

    // Llamada para inicializar el enemigo
    void startGame(Scene* scene) {
        CCLOG("Iniciando el juego...");
        spawnEnemy(scene);  // Asegúrate de que esta llamada esté siendo ejecutada
        checkEnemyInitialization();  // Verifica que enemy esté inicializado
    }
    
    void spawnEnemy(Scene* scene) {
        if (!scene) {
            CCLOG("Error: Scene es nulo.");
            return;
        }

        // Obtener el tamaño visible de la pantalla
        Size visibleSize = Director::getInstance()->getVisibleSize();
        Vec2 origin = Director::getInstance()->getVisibleOrigin();

        // Crear el sprite del enemigo
        enemy = Sprite::create("enemy_walk_1.png");

        if (!enemy) {
            CCLOG("Error: No se pudo cargar la imagen del enemigo.");
            return;
        }

        // Hacer que el enemigo sea más grande (ajustar la escala a 1.7f)
        enemy->setScale(1.7f);

        // Posicionar al enemigo fuera de la pantalla, en el lado derecho y un poquito más arriba
        Vec2 enemyPosition = Vec2(visibleSize.width + enemy->getContentSize().width, visibleSize.height / 3 + 20);
        enemy->setPosition(enemyPosition);

        // Agregar el enemigo al scene
        scene->addChild(enemy);

        // Crear la animación de caminar
        Vector<SpriteFrame*> walkFrames;
        Size enemySize = enemy->getContentSize();
        walkFrames.pushBack(SpriteFrame::create("enemy_walk_1.png", Rect(0, 0, enemySize.width, enemySize.height)));
        walkFrames.pushBack(SpriteFrame::create("enemy_walk_2.png", Rect(0, 0, enemySize.width, enemySize.height)));
        walkFrames.pushBack(SpriteFrame::create("enemy_walk_3.png", Rect(0, 0, enemySize.width, enemySize.height)));
        walkFrames.pushBack(SpriteFrame::create("enemy_walk_4.png", Rect(0, 0, enemySize.width, enemySize.height)));

        // Crear la animación de caminar
        auto walkAnimation = Animation::createWithSpriteFrames(walkFrames, 0.4f);
        auto walkAnimate = Animate::create(walkAnimation);
        if (!walkAnimate) {
            CCLOG("Error: La animación del enemigo no se creó.");
            return;
        }

        // Hacer que la animación se repita
        enemy->runAction(RepeatForever::create(walkAnimate));

        // Movimiento del enemigo hacia una posición antes de la mitad
        float stopPositionX = visibleSize.width / 2 + 130;
        auto moveToCenter = MoveTo::create(3.0f, Vec2(stopPositionX, visibleSize.height / 3 + 20));

        // Llamada para comenzar a disparar una vez llegue a la posición
        auto startShooting = CallFunc::create([this, scene]() {
            CCLOG("El enemigo ha llegado a su posición, comenzando a disparar.");

            // Verificar que el enemigo y el personaje existan antes de disparar
            Sprite* character = dynamic_cast<Sprite*>(scene->getChildByName("character"));
            if (this->enemy && character) {
                // Usar un temporizador para disparar continuamente
                scene->schedule([this, scene](float dt) {
                    shootEnemy(this->enemy, dynamic_cast<Sprite*>(scene->getChildByName("character")), scene);
                }, 1.0f, kRepeatForever, 0.0f, "enemy_shooting_key");
            } else {
                CCLOG("Error: El enemigo o el personaje no están disponibles.");
            }
        });

        // Animación de derrota después de 8 segundos
        auto defeatAnimation = CallFunc::create([this]() {
            CCLOG("El enemigo está realizando la animación de derrota.");

            // Crear una animación básica de derrota usando transformaciones
            auto fadeOut = FadeOut::create(1.0f);   // El enemigo se desvanece
            auto rotate = RotateBy::create(1.0f, 360); // Rota completamente
            auto scaleDown = ScaleTo::create(1.0f, 0.0f); // Se reduce de tamaño

            // Secuencia de animaciones
            auto defeatSequence = Spawn::create(fadeOut, rotate, scaleDown, nullptr);

            // Reproducir la animación y eliminar al enemigo al final
            auto removeEnemy = CallFunc::create([this]() {
                CCLOG("El enemigo ha sido eliminado.");
                if (this->enemy) {
                    this->enemy->removeFromParent(); // Eliminar enemigo de la escena
                    this->enemy = nullptr; // Desasociar el puntero para evitar acceso después de la eliminación
                }
            });

            // Ejecutar la animación de derrota y eliminar al enemigo
            this->enemy->runAction(Sequence::create(defeatSequence, removeEnemy, nullptr));
        });

        // Ejecutar las acciones
        auto sequence = Sequence::create(
            moveToCenter,
            startShooting,
            DelayTime::create(8.0f), // Esperar 8 segundos antes de la animación de derrota
            defeatAnimation, // Ejecutar la animación de derrota
            nullptr
        );

        // Añadir la secuencia a la acción del enemigo
        this->enemy->runAction(sequence);
        shootEnemy(enemy, character,scene);
    }


    void loadShootFrames() {
        for (int i = 1; i <= 3; ++i) { // Frames para el disparo
            std::string frameName = "shoot_" + std::to_string(i) + ".png";
            auto texture = Director::getInstance()->getTextureCache()->addImage(frameName);
            if (texture) {
                auto frame = SpriteFrame::createWithTexture(texture, Rect(0, 0, texture->getContentSize().width, texture->getContentSize().height));
                shootFrames.pushBack(frame);
                CCLOG("Frame de disparo cargado: %s", frameName.c_str());
            } else {
                CCLOG("Error al cargar el frame de disparo: %s", frameName.c_str());
            }
        }
    }
    
    
    void shootCharacter(bool isHoldingShoot) {
        // Si el botón está presionado y no está disparando, iniciar la animación y empezar a disparar balas
        
        if (isHoldingShoot) {
            if (!isShooting) {
                isShooting = true;
                
                // Iniciar la animación de disparo
                Vector<SpriteFrame*> shootFrames;
                for (int i = 1; i <= 4; ++i) {
                    std::string frameName = "shoot_" + std::to_string(i) + ".png";
                    auto texture = Director::getInstance()->getTextureCache()->addImage(frameName);
                    if (texture) {
                        auto frame = SpriteFrame::createWithTexture(texture, Rect(0, 0, texture->getContentSize().width, texture->getContentSize().height));
                        shootFrames.pushBack(frame);
                    }
                }

                if (shootFrames.empty()) return; // Si no se cargaron frames, no hacer nada

                auto shootAnimation = Animation::createWithSpriteFrames(shootFrames, 0.1f);
                auto shootAnimate = Animate::create(shootAnimation);
                auto repeatShootAnimate = RepeatForever::create(shootAnimate);
                character->setScale(1.0f);  // Tamaño del personaje
                character->runAction(repeatShootAnimate);  // Ejecutar la animación de disparo en bucle
            }

            // Disparar balas continuamente mientras el botón esté presionado
            shootBullet(character,enemy,this);
        } else {
            // Si el botón no está presionado, detener la animación de disparo
            stopShooting();
            character->setScale(1.7f);  // Cambiar el tamaño del personaje cuando no dispara
        }
    }

    void shootBullet(Sprite* character, Sprite* enemy, Scene* scene) {
        // Crear la bala
        auto bullet = Sprite::create("bullet.png");
        if (!bullet) {
            CCLOG("Error: No se pudo cargar la imagen de la bala.");
            return;
        }

        // Ajustar el tamaño y posición inicial de la bala
        bullet->setScale(0.5f);
        bullet->setPosition(character->getPosition() + Vec2(50, 20));
        scene->addChild(bullet);

        // Mover la bala hacia la derecha
        auto moveAction = MoveBy::create(1.0f, Vec2(300, 0));
        auto removeBullet = CallFunc::create([bullet]() {
            bullet->removeFromParent();
        });

        // Ejecutar la acción de movimiento seguida de la eliminación de la bala
        bullet->runAction(Sequence::create(moveAction, removeBullet, nullptr));

        CCLOG("Bala disparada desde la posición: (%f, %f)", bullet->getPosition().x, bullet->getPosition().y);
    }
    
    void shootEnemy(Sprite* enemy, Sprite* character, Scene* scene) {
        // Verificar que los parámetros no sean nulos antes de continuar
        if (!enemy || !character || !scene) {
            CCLOG("Error: Parámetros inválidos en shootEnemy. enemy: %p, character: %p, scene: %p", enemy, character, scene);
            return;
        }

        // Verificar si enemy es nulo antes de realizar cualquier operación con él
        CCLOG("enemy antes de disparar: %p", enemy);
        
        // Crear la bala
        auto enemyBullet = Sprite::create("bullet.png");
        if (!enemyBullet) {
            CCLOG("Error: No se pudo cargar la imagen de la bala del enemigo.");
            return;
        }

        // Ajustar el tamaño y voltear la bala
        enemyBullet->setScale(0.3f);
        enemyBullet->setFlippedX(true);  // Voltear la bala horizontalmente

        // Posicionar la bala en el enemigo
        enemyBullet->setPosition(enemy->getPosition() + Vec2(50, 20));  // Coloca la bala delante del enemigo
        scene->addChild(enemyBullet);

        // Calcular la dirección hacia el personaje
        Vec2 enemyPos = enemy->getPosition();
        Vec2 targetPos = character->getPosition();  // Posición del personaje (donde se dirige la bala)
        float distance = enemyPos.distance(targetPos);  // Distancia entre el enemigo y el personaje
        float duration = distance / 500.0f; // Ajustar la duración según la distancia (ajustar el valor 500 para velocidad)

        // Mover la bala hacia el personaje
        auto moveTo = MoveTo::create(duration, targetPos);  // Mover la bala hasta la posición del personaje

        // Eliminar la bala después de que haya llegado a su destino
        auto removeBullet = CallFunc::create([enemyBullet]() {
            enemyBullet->removeFromParent();
        });

        // Ejecutar las acciones de movimiento y eliminación de la bala
        enemyBullet->runAction(Sequence::create(moveTo, removeBullet, nullptr));

        // Imprimir el registro de disparo
        CCLOG("Bala disparada por el enemigo desde la posición: (%f, %f)", enemyBullet->getPosition().x, enemyBullet->getPosition().y);
    }

    // Verificación de que el enemigo es creado
   


    void stopShooting() {
        if (!isShooting) return;  // Si no está disparando, no hacer nada

        isShooting = false;
        character->stopAllActions();  // Detener la animación de disparo

        // Si lo deseas, puedes regresar al frame normal del personaje
        if (idleFrame) {
            character->setSpriteFrame(idleFrame);  // Regresar al estado idle
        }
    }

    
    void createDirectionalButtons() {
        
        if (character && enemy) {
                shootBullet(character, enemy, this); // 'this' es la escena actual
            } else {
                CCLOG("Error: character o enemy son nulos.");
            }
        auto visibleSize = Director::getInstance()->getVisibleSize();
        auto origin = Director::getInstance()->getVisibleOrigin();

        // Base position ajustada
        Vec2 basePosition = Vec2(visibleSize.width * 0.85f, visibleSize.height * 0.3f); // Mover más abajo
        float offset = 25.0f; // Separación entre los botones
        float buttonScale = 0.3f; // Tamaño de los botones

        // Botón de arriba (salto)
        auto upButton = Button::create("arrow_up.png", "arrow_up_press.png");
        upButton->setPosition(basePosition + Vec2(-offset, 0)); // Botón de arriba a la izquierda
        upButton->setScale(buttonScale);
        upButton->addTouchEventListener([this, visibleSize](Ref* sender, Widget::TouchEventType type) {
            if (type == Widget::TouchEventType::BEGAN && !isJumping) {
                jumpCharacter();  // Llamada a la función para hacer saltar al personaje
            }
        

    
        });
        
        
        this->addChild(upButton,10);
        
        
        // Botón de disparar
        // Botón de disparo
        // Botón de disparo

        // Obtener el tamaño visible de la pantalla
       
        auto shootButton = Button::create("shoot_button.png", "shoot_button_press.png");



        // Posicionar el botón en la esquina inferior izquierda
        Vec2 botonPosition = Vec2(origin.x + 50, origin.y + 30);  // Ajusta los valores si es necesario

        shootButton->setPosition(botonPosition);  // Posición ajustada (corregido)
        shootButton->setScale(0.5f);  // Hacer el botón más pequeño
        shootButton->addTouchEventListener([this](Ref* sender, Widget::TouchEventType type) {
            if (type == Widget::TouchEventType::BEGAN) {
                isHoldingShoot = true;
                shootCharacter(isHoldingShoot);  // Iniciar la animación de disparo en bucle
            }
            else if (type == Widget::TouchEventType::ENDED || type == Widget::TouchEventType::CANCELED) {
                isHoldingShoot = false;
                shootCharacter(isHoldingShoot);  // Detener la animación de disparo
            }
        });
        this->addChild(shootButton,10);

       
       
        auto downButton = Button::create("arrow_down.png", "arrow_down_press.png");
        downButton->setPosition(basePosition + Vec2(offset, +5)); // Mover el botón de abajo 6 píxeles hacia arriba
        downButton->setScale(buttonScale);
        downButton->addTouchEventListener([this](Ref* sender, Widget::TouchEventType type) {
            if (type == Widget::TouchEventType::BEGAN) {
                if (isDucking) {
                    stopDucking();  // Si ya está agachado, levantarse
                } else {
                    duckCharacter();  // Si no está agachado, agacharse
                }
            }
        });
        this->addChild(downButton,10);
        
       
    }

    void duckCharacter() {
        if (isDucking || isJumping || isMoving) return;  // Evitar agacharse mientras está en movimiento o saltando

        isDucking = true;

        // Animación de agacharse
        auto duckAnimation = Animation::createWithSpriteFrames(duckFrames, 0.1f);
        auto duckAnimate = Animate::create(duckAnimation);
        auto sequence = Sequence::create(duckAnimate, CallFunc::create([this]() {
            // Mantener al personaje en el último frame de la animación de agacharse
            character->setSpriteFrame(duckFrames.back());  // Último frame de la animación
        }), nullptr);

        character->runAction(sequence); // Ejecutar la animación y detenerse en el último frame
        character->setScale(1.7f);
    }

    
    void stopDucking() {
        if (!isDucking) return;  // Si no está agachado, no hacer nada

        isDucking = false;
        character->stopAllActions();  // Detener todas las acciones

        // Volver al frame de pie o idle
        if (idleFrame) {
            character->setSpriteFrame(idleFrame);
        }
    }
    
    
    void loadJumpFrames() {
        for (int i = 1; i <= 3; ++i) { // Frames para la subida
            std::string frameName = "jump_up_" + std::to_string(i) + ".png";
            auto texture = Director::getInstance()->getTextureCache()->addImage(frameName);
            if (texture) {
                auto frame = SpriteFrame::createWithTexture(texture, Rect(0, 0, texture->getContentSize().width, texture->getContentSize().height));
                jumpUpFrames.pushBack(frame);
                CCLOG("Frame de salto (subida) cargado: %s", frameName.c_str());
            } else {
                CCLOG("Error al cargar el frame de salto (subida): %s", frameName.c_str());
            }
        }

        for (int i = 1; i <= 3; ++i) { // Frames para la bajada
            std::string frameName = "jump_down_" + std::to_string(i) + ".png";
            auto texture = Director::getInstance()->getTextureCache()->addImage(frameName);
            if (texture) {
                auto frame = SpriteFrame::createWithTexture(texture, Rect(0, 0, texture->getContentSize().width, texture->getContentSize().height));
                jumpDownFrames.pushBack(frame);
                CCLOG("Frame de salto (bajada) cargado: %s", frameName.c_str());
            } else {
                CCLOG("Error al cargar el frame de salto (bajada): %s", frameName.c_str());
            }
        }
        
        
        for (int i = 1; i <= 4; ++i) { // Frames para agacharse
               std::string frameName = "duck_" + std::to_string(i) + ".png";
               auto texture = Director::getInstance()->getTextureCache()->addImage(frameName);
               if (texture) {
                   auto frame = SpriteFrame::createWithTexture(texture, Rect(0, 0, texture->getContentSize().width, texture->getContentSize().height));
                   duckFrames.pushBack(frame);
                   CCLOG("Frame de agacharse cargado: %s", frameName.c_str());
               } else {
                   CCLOG("Error al cargar el frame de agacharse: %s", frameName.c_str());
               }
           }
    }


        // Función para realizar el salto con animación
    void jumpCharacter() {
        if (isJumping || isMoving) return; // Evitar salto si ya está en movimiento o saltando

        isJumping = true;

        // Aseguramos que la escala del personaje sea 1.0 durante el salto
        character->setScale(1.3f);  // Asegurar que el personaje esté en su escala original durante el salto

        // Animación para la subida
        auto jumpUpAnimation = Animation::createWithSpriteFrames(jumpUpFrames, 0.1f);
        auto jumpUpAnimate = Animate::create(jumpUpAnimation);

        // Animación para la bajada
        auto jumpDownAnimation = Animation::createWithSpriteFrames(jumpDownFrames, 0.1f);
        auto jumpDownAnimate = Animate::create(jumpDownAnimation);

        // Movimiento hacia arriba y hacia abajo
        auto jumpUp = MoveBy::create(0.3f, Vec2(0, 150));  // Subir 150 px
        auto jumpDown = MoveBy::create(0.3f, Vec2(0, -150)); // Bajar 150 px

        // Secuencia de animación y movimiento
        auto jumpSequence = Sequence::create(
            jumpUpAnimate,    // Animación hacia arriba
            jumpUp,           // Movimiento hacia arriba
            jumpDownAnimate,  // Animación hacia abajo
            jumpDown,         // Movimiento hacia abajo
            CallFunc::create([this]() {
                isJumping = false;        // Finalizar el estado de salto
                character->setScale(1.5f); // Restaurar escala original al terminar el salto
            }),
            nullptr
        );

        character->runAction(jumpSequence);  // Ejecutar la secuencia completa de salto
    }

    
    void loadFrames() {
        // Cargar los frames de caminata hacia la derecha
        for (int i = 1; i <= 6; ++i) {
            std::string frameName = "walk_right_" + std::to_string(i) + ".png";
            auto texture = Director::getInstance()->getTextureCache()->addImage(frameName);
            if (texture) {
                auto frame = SpriteFrame::createWithTexture(texture, Rect(0, 0, texture->getContentSize().width, texture->getContentSize().height));
                walkRightFrames.pushBack(frame);
                CCLOG("Frame cargado correctamente: %s", frameName.c_str());
            } else {
                CCLOG("Error al cargar la textura: %s", frameName.c_str());
            }
        }

        // Cargar los frames de caminata hacia la izquierda
        for (int i = 1; i <= 6; ++i) {
            std::string frameName = "walk_left_" + std::to_string(i) + ".png";
            auto texture = Director::getInstance()->getTextureCache()->addImage(frameName);
            if (texture) {
                auto frame = SpriteFrame::createWithTexture(texture, Rect(0, 0, texture->getContentSize().width, texture->getContentSize().height));
                walkLeftFrames.pushBack(frame);
                CCLOG("Frame cargado correctamente: %s", frameName.c_str());
            } else {
                CCLOG("Error al cargar la textura: %s", frameName.c_str());
            }
        }
    }

   
    
    // Función de movimiento que maneja ambos casos (toque corto y largo)
    void moveCharacter(bool toRight, bool isShortTouch) {
        Vec2 currentPos = character->getPosition();
        auto visibleSize = Director::getInstance()->getVisibleSize();

        if (isMoving) return;  // Si ya está en movimiento, no iniciar otro
        isMoving = true;

        // Configuración de la animación de caminar
        Vector<SpriteFrame*>& frames = toRight ? walkRightFrames : walkLeftFrames;
        if (frames.empty()) {
            isMoving = false;
            return;
        }

        auto animation = Animation::createWithSpriteFrames(frames, 0.1f);  // Velocidad de la animación
        auto animate = Animate::create(animation);

        // Si es un toque largo, hacer la animación en bucle
        if (!isShortTouch) {
            auto repeatAnimate = RepeatForever::create(animate);
            repeatAnimate->setTag(1);  // Tag para identificar la animación
            character->runAction(repeatAnimate);  // Iniciar la animación en bucle
        } else {
            // Si es un toque corto, hacer solo un paso
            auto stepAction = MoveBy::create(0.3f, Vec2(toRight ? 50.0f : -50.0f, 0));  // Paso corto
            character->runAction(Sequence::create(
                stepAction,
                CallFunc::create([this]() {
                    character->stopActionByTag(1); // Detener la animación si es un toque corto
                    if (idleFrame) {
                        character->setSpriteFrame(idleFrame); // Regresar al frame inicial
                    }
                    isMoving = false;  // Terminar movimiento
                }),
                nullptr
            ));
        }

        // Movimiento continuo para toque largo
        if (!isShortTouch) {
            auto moveAction = RepeatForever::create(MoveBy::create(0.1f, Vec2(toRight ? 10.0f : -10.0f, 0)));
            moveAction->setTag(2);  // Tag para identificar el movimiento continuo
            character->runAction(moveAction);
        }

        // Comprobar si el personaje ha llegado al final de 'background1' y mover 'background2'
        if (toRight && currentPos.x >= visibleSize.width - character->getContentSize().width / 2) {
            // Si el personaje está en el borde derecho, mover 'background2' hacia la izquierda
            auto moveAction2 = MoveBy::create(0.1f, Vec2(-10.0f, 0));  // Desplazar background2
            background2->runAction(moveAction2);
        }
    }

    // Función cuando se comienza a tocar la pantalla
    bool onTouchBegan(Touch* touch, Event* event) {
           Vec2 touchLocation = touch->getLocation();
           auto visibleSize = Director::getInstance()->getVisibleSize();

           if (isMoving || isJumping) return false;  // Evitar acciones mientras está en movimiento o saltando
        

           // Movimiento horizontal
           isHolding = true;
           moveCharacter(touchLocation.x > visibleSize.width / 2, false);
           return true;
       }

    // Función cuando se termina de tocar la pantalla
    void onTouchEnded(Touch* touch, Event* event) {
        isHolding = false;
        
        
        if (isDucking) {
                stopDucking();
            }

        
        // Detener cualquier acción de movimiento y animación
        character->stopActionByTag(2);  // Detener movimiento continuo
        character->stopActionByTag(1);  // Detener animación

        // Regresar al estado idle (inactivo)
        if (idleFrame) {
            character->setSpriteFrame(idleFrame);  // Mostrar el frame estático
        }

        isMoving = false;
    }


    

    CREATE_FUNC(FirstLevelScene);
};
    


// Declaración de la escena del menú de personajes
class CharacterMenuScene : public Scene {
public:
    static Scene* createScene() {
        return CharacterMenuScene::create();
    }

    virtual bool init() {
        // Inicialización de la nueva escena
        if (!Scene::init()) {
            return false;
        }

        // Tamaño de la pantalla
        auto visibleSize = Director::getInstance()->getVisibleSize();
        auto origin = Director::getInstance()->getVisibleOrigin();

        // Fondo del menú de selección de personajes
        auto background = Sprite::create("menu4.png");
        if (background) {
            background->setPosition(Vec2(
                visibleSize.width / 2 + origin.x,
                visibleSize.height / 2 + origin.y
            ));
            background->setContentSize(visibleSize);
            this->addChild(background, -1);
            
            
        } else {
            CCLOG("Error: No se pudo cargar 'menu_fondo_personajes.png'");
        }
        
        auto characterSprite = Sprite::create("personaje.png"); // Imagen del personaje
            if (characterSprite) {
                characterSprite->setScale(3.2f); // Ajustar escala del personaje
                characterSprite->setPosition(Vec2(
                    visibleSize.width / 2 + origin.x - 80.0f,    // Centrado horizontalmente
                    visibleSize.height / 2 + origin.y - 30.0f// 60% de la altura
                ));
                this->addChild(characterSprite, 1); // Añadir al nivel superior
                
                
                auto descriptionLabel = Label::createWithTTF("DUKE: \nLíder audaz y experto\nen combate y siempre\nlisto para la acción.","fonts/pixel.ttf", 9);
                    descriptionLabel->setTextColor(Color4B::WHITE);  // Color del texto
                    descriptionLabel->setAnchorPoint(Vec2(0, 0.5f)); // Alineación del texto

                    // Posicionar el texto al lado derecho del personaje
                descriptionLabel->setPosition(Vec2(characterSprite->getPositionX() - characterSprite->getContentSize().width / 2 + 170,
                                                       characterSprite->getPositionY() + 30)); // Ajusta estos valores

                    // Añadir el texto a la escena
                    this->addChild(descriptionLabel);
            }
        // Crear el segundo personaje
               // === Botón "Escoger" debajo del personaje ===
            auto chooseButton = MenuItemImage::create(
                "select1.png",         // Imagen normal del botón
                "selectpress.png", // Imagen presionada del botón
                [](Ref* sender) {
                    CCLOG("Personaje seleccionado");
                    // Aquí puedes manejar la lógica de selección del personaje
                    
            auto firstLevelScene = FirstLevelScene::createScene(); // Cambiar a la escena del primer nivel
            auto transition = TransitionFade::create(0.5f, firstLevelScene); // Transición suave
            Director::getInstance()->replaceScene(transition); // Reemplazar la escena actual por la nueva
                });
            chooseButton->setScale(0.13f); // Ajustar escala del botón
            chooseButton->setPosition(Vec2(
                visibleSize.width / 2 + origin.x + 60.0f,  // Centrado horizontalmente
                visibleSize.height * 0.3f + origin.y - 10.0f // 30% de la altura
            ));
   
        auto chooseMenu = Menu::create(chooseButton, nullptr);
            chooseMenu->setPosition(Vec2::ZERO); // Posición personalizada
            this->addChild(chooseMenu, 2);
        
        
        
        
        auto backButton = MenuItemImage::create(
                "back.png",        // Imagen normal del botón
                "botonpress1.png", // Imagen presionada del botón
                [](Ref* sender) {
                    CCLOG("Botón de Regresar presionado");
                    auto mainMenuScene = HelloWorld::createScene(); // Vuelve al menú principal
                    Director::getInstance()->replaceScene(TransitionFade::create(0.5f, mainMenuScene)); // Transición suave
                });
            backButton->setScale(0.4f); // Ajusta el tamaño del botón

            // Posicionar el botón en la esquina inferior derecha
        backButton->setPosition(Vec2(
            backButton->getContentSize().width * 0.3f + origin.x, // A la izquierda, ligeramente separado del borde
            backButton->getContentSize().height * 0.3f + origin.y // En la parte inferior, ligeramente separado del borde
            ));

            // Crear el menú y agregar el botón de regresar
            auto backMenu = Menu::create(backButton, nullptr);
            backMenu->setPosition(Vec2::ZERO); // Desactivar la posición predeterminada
            this->addChild(backMenu, 1); // Añadir el menú con el botón de regreso al frente

            // Resto del código de la escena (botones de selección de personajes, etc.)
            // ...

            return true;
        }


    CREATE_FUNC(CharacterMenuScene);
};

// Declaración de una ventana de configuración dentro de la escena principal
class ConfigLayer : public Layer {
public:
    virtual bool init() {
        auto visibleSize = Director::getInstance()->getVisibleSize();
        auto origin = Director::getInstance()->getVisibleOrigin();

        // Fondo semitransparente para oscurecer el resto de la escena
        auto background = LayerColor::create(Color4B(0, 0, 0, 150));
        this->addChild(background, -1);

        // Ventana de configuración
        auto configWindow = Sprite::create("configuracion.png");
        if (configWindow) {
            configWindow->setPosition(Vec2(
                visibleSize.width / 2 + origin.x,
                visibleSize.height / 2 + origin.y
            ));
            configWindow->setScale(1.5f);
            this->addChild(configWindow, 1);
        }

        // Menú de botones dentro de la ventana de configuración
        auto soundButton = MenuItemImage::create(
            "volumen.png", "volumen.png",
            [](Ref* sender) {
                CCLOG("Botón de Sonido presionado");
            });
        soundButton->setScale(0.5f);
        soundButton->setPosition(Vec2(-50.0f, 30.0f));

        auto musicButton = MenuItemImage::create(
            "muscia.png", "muscia.png",
            [](Ref* sender) {
                CCLOG("Botón de Música presionado");
            });
        musicButton->setScale(0.5f);
        musicButton->setPosition(Vec2(50.0f, 30.0f));

        auto closeButton = MenuItemImage::create(
            "salir.png", "salirpress.png",
            [this](Ref* sender) {
                this->removeFromParent();
            });
        closeButton->setScale(0.3f);
        closeButton->setPosition(Vec2(0.0f, -50.0f));

        auto menu = Menu::create(soundButton, musicButton, closeButton, nullptr);
        menu->setPosition(Vec2::ZERO);
        configWindow->addChild(menu);

        // Bloquear interacción con el fondo
        auto touchListener = EventListenerTouchOneByOne::create();
        touchListener->onTouchBegan = [configWindow](Touch* touch, Event* event) {
            // Verifica si el toque está dentro de la ventana de configuración
            Vec2 locationInNode = configWindow->convertToNodeSpace(touch->getLocation());
            Size size = configWindow->getContentSize();
            Rect rect = Rect(0, 0, size.width, size.height);

            // Si el toque está fuera de la ventana, bloquea el evento
            if (!rect.containsPoint(locationInNode)) {
                return true; // Absorber el toque
            }
            return false; // Permitir la interacción dentro de la ventana
        };
        touchListener->setSwallowTouches(true);
        _eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

        return true;
    }

    CREATE_FUNC(ConfigLayer);
};

// Escena principal: HelloWorld

Scene* HelloWorld::createScene() {
    return HelloWorld::create();
}

bool HelloWorld::init() {
    if (!Scene::init()) {
        return false;
    }

    // Tamaño de la pantalla
    auto visibleSize = Director::getInstance()->getVisibleSize();
    auto origin = Director::getInstance()->getVisibleOrigin();

    // === Agregar imagen de fondo ===
    auto background = Sprite::create("fondo.png");
    if (background) {
        background->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        background->setContentSize(visibleSize); // Ajustar al tamaño de la pantalla
        this->addChild(background, -1);
    }

    // === Agregar imagen con el nombre del juego ===
       auto title = Sprite::create("logo2.png");
       if (!title) {
           CCLOG("Error: No se pudo cargar la imagen 'titulo.png'");
           return false;
       }
       title->setScale(3.0f); // Reducir tamaño para ajustarse a la pantalla
       float offsetY = title->getContentSize().height * 3.0f / 2.0f + 20.0f; // Mitad del tamaño escalado

       title->setPosition(Vec2(
           visibleSize.width / 2 + origin.x + 20.0f,
                               visibleSize.height * 2 + origin.y - offsetY// Ajustar al 70% de la altura
       ));
       this->addChild(title, 1); // Añadir al nivel superior

    // === Botón Jugar ===
    auto playButton = MenuItemImage::create(
        "pla.png",    // Imagen normal
        "playpress2.png",   // Imagen presionada
        [](Ref* sender) {
            CCLOG("Botón de Jugar presionado");

            // Precargar recursos de la nueva escena
            //AudioEngine::preload("character_menu_music.mp3");

            // Crear la escena del menú de personajes
            auto characterMenuScene = CharacterMenuScene::createScene();

            // Usar una transición más ligera
            auto transition = TransitionCrossFade::create(0.3f, characterMenuScene);
            Director::getInstance()->replaceScene(transition);

            // Eliminar texturas innecesarias
            Director::getInstance()->getTextureCache()->removeUnusedTextures();
        });

    playButton->setScale(0.25f);
    playButton->setPosition(Vec2(
        visibleSize.width / 2 + origin.x,
        visibleSize.height * 0.30f + origin.y
    ));


    // === Botón Salir ===
    auto exitButton = MenuItemImage::create(
        "exit2.png",    // Imagen normal
        "exit2press.png",   // Imagen presionada
        [](Ref* sender) {
            CCLOG("Botón de Salir presionado");
            Director::getInstance()->end();
        });
    exitButton->setScale(0.25f);
    exitButton->setPosition(Vec2(
        visibleSize.width / 2 + origin.x,
        playButton->getPositionY() - playButton->getContentSize().height * 0.2f - 8
    ));

    // Crear menú para los botones Jugar y Salir
    auto menu = Menu::create(playButton, exitButton, nullptr);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu);

    // === Botón Configuración ===
    auto configButton = MenuItemImage::create(
        "conf2.png",    // Imagen normal
        "confpress2.png",   // Imagen presionada
            [this](Ref* sender) {
            CCLOG("Botón de Configuración presionado");
            auto configLayer = ConfigLayer::create();
            this->addChild(configLayer, 10); // Añadir al frente de todo

        });
    configButton->setScale(0.2f);
    configButton->setPosition(Vec2(
        visibleSize.width - configButton->getContentSize().width * 0.1f + origin.x,
        visibleSize.height - configButton->getContentSize().height * 0.1f + origin.y
    ));

    // Crear menú para el botón de Configuración
    auto configMenu = Menu::create(configButton, nullptr);
    configMenu->setPosition(Vec2::ZERO);
    this->addChild(configMenu);

    return true;
}

